﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Illusory Studios LLC")]
[assembly: AssemblyCopyright("Copyright © 2010-2013 James F. Bellinger <http://www.zer7.com/software/hidsharp>")]
[assembly: AssemblyDescription("Helpers for common HID class devices")]
[assembly: AssemblyProduct("HidSharp")]
[assembly: AssemblyTitle("HidSharp.DeviceHelpers")]
[assembly: AssemblyFileVersion("1.3.0.0")]
[assembly: AssemblyVersion("1.3.0.0")]

[assembly: ComVisible(false)]
[assembly: Guid("8729AEA8-40C1-4100-8334-DB0A251DFFDE")]
