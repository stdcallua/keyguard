﻿#region License
/* Copyright 2012-2017 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

#define SAMPLE_OPEN_AND_READ
//#define SAMPLE_DYMO_SCALE

using System;
using System.Diagnostics;
using System.Linq;
using System.Threading;

namespace HidSharp.Test
{
    class Program
    {
        static byte[] HexToBytes(string hex)
        {
            hex = hex.Replace(" ", "");
            return Enumerable.Range(0, hex.Length / 2).Select(x => Convert.ToByte(hex.Substring(x * 2, 2), 16)).ToArray();
        }

        static void Main(string[] args)
        {
            var list = DeviceList.Local;
            list.Changed += (sender, e) => Console.WriteLine("Device list changed.");

            var stopwatch = Stopwatch.StartNew();
            var deviceList = list.GetHidDevices().ToArray();

            Console.WriteLine("Complete device list (took {0} ms to get {1} devices):",
                              stopwatch.ElapsedMilliseconds, deviceList.Length);
            foreach (HidDevice dev in deviceList)
            {
                Console.WriteLine(dev.DevicePath);
                Console.WriteLine(dev);

                Console.WriteLine("Serial Ports: {0}", string.Join(",", dev.GetSerialPorts()));

                byte[] reportDescriptor = dev.GetReportDescriptor();
                Console.WriteLine("Report Descriptor: {0} bytes", reportDescriptor.Length);
            }
            Console.WriteLine("Press Enter to continue."); Console.ReadLine();

            Console.WriteLine();

            Console.WriteLine("Opening HID class device...");

#if SAMPLE_OPEN_AND_READ
            var device = list.GetHidDevices(0x268b, 0x0101).FirstOrDefault(d => d.GetMaxInputReportLength() == 63);
            if (device == null) { Console.WriteLine("Failed to open device."); Environment.Exit(1); }

            Console.Write(@"
Max Lengths:
  Input:   {0}
  Output:  {1}
  Feature: {2}

The operating system name for this device is:
  {3}

"
, device.GetMaxInputReportLength()
, device.GetMaxOutputReportLength()
, device.GetMaxFeatureReportLength()
, device.DevicePath
);

            try
            {
                Console.WriteLine("Serial Ports: " + string.Join(", ", device.GetSerialPorts()));
            }
            catch (NotSupportedException)
            {
                Console.WriteLine("Serial Ports: Unknown on this platform.");
            }

            HidStream stream;
            if (!device.TryOpen(out stream)) { Console.WriteLine("Failed to open device."); Environment.Exit(2); }

            using (stream)
            {
                int n = 0;
                while (true)
                {
                    var bytes = new byte[device.GetMaxInputReportLength()];
                    int count;

                    try
                    {
                        count = stream.Read(bytes, 0, bytes.Length);
                    }
                    catch (TimeoutException)
                    {
                        Console.WriteLine("Read timed out.");
                        continue;
                    }

                    if (count > 0)
                    {
                        Console.Write("* {0} : ", count);

                        for (int i = 0; i < count && i < 62; i++)
                        {
                            Console.Write("{0:X} ", bytes[i]);
                        }

                        Console.WriteLine();
                        if (++n == 100) { break; }
                    }
                }
            }
#elif SAMPLE_DYMO_SCALE
            HidDevice scale = loader.GetDeviceOrDefault(24726, 344);
            if (scale == null) { Console.WriteLine("Failed to find scale device."); Environment.Exit(1); }

            HidStream stream;
            if (!scale.TryOpen(out stream)) { Console.WriteLine("Failed to open scale device."); Environment.Exit(2); }

            using (stream)
            {
                int n = 0; DymoScale scaleReader = new DeviceHelpers.DymoScale(stream);
                while (true)
                {
                    int value, exponent;
                    DymoScaleUnit unit; string unitName;
                    DymoScaleStatus status; string statusName;
                    bool buffered;

                    scaleReader.ReadSample(out value, out exponent, out unit, out status, out buffered);
                    unitName = DymoScale.GetNameFromUnit(unit);
                    statusName = DymoScale.GetNameFromStatus(status);

                    Console.WriteLine("{4}  {0}: {1}x10^{2} {3} ", statusName, value, exponent, unitName, buffered ? "b" : " ");
                    if (!buffered) { if (++n == 100) { break; } }
                }
            }
#else
#error "No sample selected."
#endif

            Console.WriteLine("Press a key to exit...");
            Console.ReadKey();

            /*
            // TODO: Move this into the HidSharp.Net example.
            {
                // Test Curve25519.
                var alice_public = HexToBytes("8520f0098930a754748b7ddcb43ef75a0dbf3a0d26381af4eba4a98eaa9b4e6a");
                var alice_private = HexToBytes("77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a");
                var alice_private_calc = CV.ConvertToPrivateKey(alice_private);
                var alice_public_calc = CV.DerivePublicKey(alice_private_calc);
                Debug.Assert(alice_public.SequenceEqual(alice_public_calc));

                var bob_private = HexToBytes("5dab087e624a8a4b79e17f8b83800ee66f3bb1292618b6fd1c2f8b27ff88e0eb");
                var bob_public = HexToBytes("de9edb7d7b7dc1b4d35b61c2ece435373f8343c85b78674dadfc7e146f882b4f");
                var bob_private_calc = CV.ConvertToPrivateKey(bob_private);
                var bob_public_calc = CV.DerivePublicKey(bob_private_calc);
                Debug.Assert(bob_public.SequenceEqual(bob_public_calc));

                var alice_mult_bob = HexToBytes("4A5D9D5BA4CE2DE1728E3BF480350F25E07E21C947D19E3376F09B3C1E161742");
                var alice_mult_bob_calc = CV.DeriveSecretKey(alice_private_calc, bob_public_calc);
                var bob_mult_alice_calc = CV.DeriveSecretKey(bob_private_calc, alice_public_calc);
                Debug.Assert(alice_mult_bob.SequenceEqual(alice_mult_bob_calc));
                Debug.Assert(alice_mult_bob.SequenceEqual(bob_mult_alice_calc));
            }
            
            { 
                // Test Curve25519 exchange.
                var pexClient = new HidSharp.Net.Utility.Curve25519PasswordExchange(System.Text.Encoding.UTF8.GetBytes("A"));
                var pexServer = new HidSharp.Net.Utility.Curve25519PasswordExchange(System.Text.Encoding.UTF8.GetBytes("A"));
                var pexClientXchg = pexClient.GetExchange();
                var pexServerXchg = pexServer.GetExchange();
                var pexClientKey = pexClient.GetSessionKey(pexServerXchg);
                var pexServerKey = pexServer.GetSessionKey(pexClientXchg);
            }
            */
        }
    }
}
