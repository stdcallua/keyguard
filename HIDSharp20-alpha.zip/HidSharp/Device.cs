﻿#region License
/* Copyright 2017 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System;
using System.Diagnostics;

namespace HidSharp
{
    public abstract class Device
    {
        /// <summary>
        /// Makes a connection to the device, or throws an exception if the connection cannot be made.
        /// </summary>
        /// <returns>The stream to use to communicate with the device.</returns>
        public DeviceStream Open()
        {
            return Open(null);
        }

        public DeviceStream Open(OpenConfiguration openConfig)
        {
            return OpenDeviceAndRestrictAccess(openConfig ?? new OpenConfiguration());
        }

        protected virtual DeviceStream OpenDeviceAndRestrictAccess(OpenConfiguration openConfig)
        {
            bool exclusive = (bool)openConfig.GetOption(OpenOption.Exclusive);

            DeviceOpenUtility openUtility = null;
            if (exclusive)
            {
                openUtility = new DeviceOpenUtility(this, openConfig);
                openUtility.Open();
            }

            DeviceStream stream;
            try
            {
                stream = OpenDeviceDirectly(openConfig);
                if (exclusive)
                {
                    stream.Closed += (sender, e) => openUtility.Close();
                    openUtility.InterruptRequested += (sender, e) =>
                        {
                            stream.OnInterruptRequested();
                            Debug.WriteLine("** HIDSharp delivered an interrupt request.");
                        };
                }
            }
            catch
            {
                if (exclusive) { openUtility.Close(); }
                throw;
            }

            return stream;
        }

        protected abstract DeviceStream OpenDeviceDirectly(OpenConfiguration openConfig);

        /// <summary>
        /// Tries to make a connection to the device.
        /// </summary>
        /// <param name="stream">The stream to use to communicate with the device.</param>
        /// <returns><c>true</c> if the connection was successful.</returns>
        public bool TryOpen(out DeviceStream stream)
        {
            return TryOpen(null, out stream);
        }

        public bool TryOpen(OpenConfiguration openConfig, out DeviceStream stream)
        {
            Exception exception;
            return TryOpen(openConfig, out stream, out exception);
        }

        public bool TryOpen(OpenConfiguration openConfig, out DeviceStream stream, out Exception exception)
        {
            try
            {
                stream = Open(openConfig); exception = null; return true;
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
                stream = null; exception = e; return false;
            }
        }

        /// <summary>
        /// Returns the file system path of the device.
        /// This can be used to check permissions on Linux hidraw, for instance.
        /// </summary>
        /// <returns>The file system path.</returns>
        public abstract string GetFileSystemName();

        /// <summary>
        /// Returns a name appropriate for display.
        /// </summary>
        /// <returns>The friendly name.</returns>
        public abstract string GetFriendlyName();

        /// <summary>
        /// The operating system's name for the device.
        /// 
        /// If you have multiple devices with the same Vendor ID, Product ID, Serial Number. etc.,
        /// this may be useful for differentiating them.
        /// </summary>
        public abstract string DevicePath
        {
            get;
        }

        /// <summary>
        /// The low-level implementation being used for the device.
        /// </summary>
        public virtual Guid NativeImplementation
        {
            get { return HidSharp.NativeImplementation.Unknown; }
        }
    }
}
