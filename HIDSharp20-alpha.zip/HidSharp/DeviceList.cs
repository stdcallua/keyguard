﻿#region License
/* Copyright 2015-2016 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices;

namespace HidSharp
{
    /// <summary>
    /// Provides a list of all available devices.
    /// </summary>
    [ComVisible(true), Guid("80614F94-0742-4DE4-8AE9-DF9D55F870F2")]
    public class DeviceList
    {
        /// <exclude />
        [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
        public static event EventHandler<DeviceListChangedEventArgs> DeviceListChanged;

        /// <summary>
        /// Occurs when a device is connected or disconnected.
        /// </summary>
        public event EventHandler<DeviceListChangedEventArgs> Changed;

        static DeviceList()
        {
            Local = new DeviceList();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceList"/> class.
        /// </summary>
        protected DeviceList()
        {

        }

        /// <inheritdoc/>
        public override string ToString()
        {
            return Platform.HidSelector.Instance.FriendlyName; // This value is useful for debugging.
        }

        /// <summary>
        /// Gets a list of all connected HID devices.
        /// </summary>
        /// <returns>The device list.</returns>
        public IEnumerable<HidDevice> GetHidDevices()
        {
            return GetAllDevices().OfType<HidDevice>();
        }

        /// <summary>
        /// Gets a list of connected HID devices, filtered by some criteria.
        /// </summary>
        /// <param name="vendorID">The vendor ID, or null to not filter by vendor ID.</param>
        /// <param name="productID">The product ID, or null to not filter by product ID.</param>
        /// <param name="releaseNumberBcd">The device release number in binary-coded decimal, or null to not filter by device release number.</param>
        /// <param name="serialNumber">The serial number, or null to not filter by serial number.</param>
        /// <returns>The filtered device list.</returns>
        public IEnumerable<HidDevice> GetHidDevices(int? vendorID = null, int? productID = null, int? releaseNumberBcd = null, string serialNumber = null)
        {
            return GetAllDevices(d => DeviceFilterHelper.MatchHidDevices(d, vendorID, productID, releaseNumberBcd, serialNumber)).Cast<HidDevice>();
        }

        /// <summary>
        /// Gets a list of all connected serial devices.
        /// </summary>
        /// <returns>The device list.</returns>
        public IEnumerable<SerialDevice> GetSerialDevices()
        {
            return GetAllDevices().OfType<SerialDevice>();
        }

        /// <summary>
        /// Gets a list of all connected HID and serial devices.
        /// </summary>
        /// <returns>The device list.</returns>
        public virtual IEnumerable<Device> GetAllDevices()
        {
            return Platform.HidSelector.Instance.GetDevices();
        }

        /// <summary>
        /// Gets a list of connected devices, filtered by some criteria.
        /// </summary>
        /// <param name="filter">The filter criteria.</param>
        /// <returns>The filtered device list.</returns>
        public IEnumerable<Device> GetAllDevices(DeviceFilter filter)
        {
            Throw.If.Null(filter, "filter");
            return GetAllDevices().Where(device => filter(device));
        }

        /// <summary>
        /// Gets the first connected HID device that matches specified criteria.
        /// </summary>
        /// <param name="vendorID">The vendor ID, or null to not filter by vendor ID.</param>
        /// <param name="productID">The product ID, or null to not filter by product ID.</param>
        /// <param name="releaseNumberBcd">The device release number in binary-coded decimal, or null to not filter by device release number.</param>
        /// <param name="serialNumber">The serial number, or null to not filter by serial number.</param>
        /// <returns>The device, or null if none was found.</returns>
        public HidDevice GetHidDeviceOrNull(int? vendorID = null, int? productID = null, int? releaseNumberBcd = null, string serialNumber = null)
        {
            return GetHidDevices(vendorID, productID, releaseNumberBcd, serialNumber).FirstOrDefault();
        }

        public bool TryGetHidDevice(out HidDevice device, int? vendorID = null, int? productID = null, int? releaseNumberBcd = null, string serialNumber = null)
        {
            device = GetHidDeviceOrNull(vendorID, productID, releaseNumberBcd, serialNumber);
            return device != null;
        }

        /// <summary>
        /// Gets the connected serial device with the specific port name.
        /// </summary>
        /// <param name="portName">The port name.</param>
        /// <returns>The device, or null if none was found.</returns>
        public SerialDevice GetSerialDeviceOrNull(string portName)
        {
            return GetSerialDevices().Where(d => d.DevicePath == portName).FirstOrDefault();
        }

        public bool TryGetSerialDevice(out SerialDevice device, string portName)
        {
            device = GetSerialDeviceOrNull(portName);
            return device != null;
        }

        /// <summary>
        /// Raises the <see cref="Changed"/> event.
        /// </summary>
        public void RaiseChanged()
        {
            EventHandler<DeviceListChangedEventArgs> ev;

            ev = Changed;
            if (ev != null) { ev(this, new DeviceListChangedEventArgs()); }

            ev = DeviceListChanged;
            if (ev != null) { ev(this, new DeviceListChangedEventArgs()); }
        }

        /// <summary>
        /// <c>true</c> if drivers are presently being installed.
        /// </summary>
        public virtual bool AreDriversBeingInstalled
        {
            get { return Platform.HidSelector.Instance.AreDriversBeingInstalled; }
        }

        /// <summary>
        /// The list of devices on this computer.
        /// </summary>
        public static DeviceList Local
        {
            get;
            private set;
        }
    }
}
