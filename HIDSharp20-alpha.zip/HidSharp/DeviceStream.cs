﻿#region License
/* Copyright 2016 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System;
using System.IO;

namespace HidSharp
{
    public abstract class DeviceStream : Stream
    {
        /// <summary>
        /// Occurs when the stream is closed.
        /// </summary>
        public event EventHandler Closed;

        /// <summary>
        /// Occurs when <see cref="OpenOption.Interruptible"/> is <c>true</c> and another process or thread with higher priority
        /// would like to open the stream.
        /// </summary>
        public event EventHandler InterruptRequested;

        /// <exclude/>
        protected DeviceStream(Device device)
        {
            Throw.If.Null(device);
            Device = device;
            ReadTimeout = 3000;
            WriteTimeout = 3000;
        }

        /// <inheritdoc/>
        protected override void Dispose(bool disposing)
        {
            try
            {
                OnClosed();
            }
            catch
            {

            }

            base.Dispose(disposing);
        }

        /// <inheritdoc/>
        public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
        {
            Throw.If.OutOfRange(buffer, offset, count);
            return AsyncResult<int>.BeginOperation(delegate()
            {
                return Read(buffer, offset, count);
            }, callback, state);
        }

        /// <inheritdoc/>
        public override int EndRead(IAsyncResult asyncResult)
        {
            Throw.If.Null(asyncResult, "asyncResult");
            return ((AsyncResult<int>)asyncResult).EndOperation();
        }

        /// <inheritdoc/>
        public override IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
        {
            Throw.If.OutOfRange(buffer, offset, count);
            return AsyncResult<int>.BeginOperation(delegate()
            {
                Write(buffer, offset, count); return 0;
            }, callback, state);
        }

        /// <inheritdoc/>
        public override void EndWrite(IAsyncResult asyncResult)
        {
            Throw.If.Null(asyncResult, "asyncResult");
            ((AsyncResult<int>)asyncResult).EndOperation();
        }

        /// <exclude />
        public override long Seek(long offset, SeekOrigin origin)
        {
            throw new NotSupportedException();
        }

        /// <exclude />
        public override void SetLength(long value)
        {
            throw new NotSupportedException();
        }

        protected virtual void OnClosed()
        {
            RaiseClosed();
        }

        protected void RaiseClosed()
        {
            var ev = Closed;
            if (ev != null) { ev(this, EventArgs.Empty); }
        }

        protected internal virtual void OnInterruptRequested()
        {
            RaiseInterruptRequested();
        }

        protected void RaiseInterruptRequested()
        {
            var ev = InterruptRequested;
            if (ev != null) { ev(this, EventArgs.Empty); }
        }

        /// <exclude />
        public override bool CanRead
        {
            get { return true; }
        }

        /// <exclude />
        public override bool CanSeek
        {
            get { return false; }
        }

        /// <exclude />
        public override bool CanWrite
        {
            get { return true; }
        }

        /// <exclude />
        public override bool CanTimeout
        {
            get { return true; }
        }

        /// <summary>
        /// Gets the <see cref="Device"/> associated with this stream.
        /// </summary>
        public Device Device
        {
            get;
            private set;
        }

        /// <exclude />
        public override long Length
        {
            get { throw new NotSupportedException(); }
        }

        /// <exclude />
        public override long Position
        {
            get { throw new NotSupportedException(); }
            set { throw new NotSupportedException(); }
        }

        /// <summary>
        /// The maximum amount of time, in milliseconds, to wait for the device to send some data.
        /// 
        /// The default is 3000 milliseconds.
        /// To disable the timeout, set this to <see cref="Timeout.Infinite"/>.
        /// </summary>
        public abstract override int ReadTimeout
        {
            get;
            set;
        }

        /// <summary>
        /// The maximum amount of time, in milliseconds, to wait for the device to receive the data.
        /// 
        /// The default is 3000 milliseconds.
        /// To disable the timeout, set this to <see cref="Timeout.Infinite"/>.
        /// </summary>
        public abstract override int WriteTimeout
        {
            get;
            set;
        }

        /// <summary>
        /// An object storing user-defined data about the stream.
        /// </summary>
        public object Tag
        {
            get;
            set;
        }
    }
}
