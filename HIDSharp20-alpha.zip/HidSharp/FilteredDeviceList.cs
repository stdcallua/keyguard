﻿#region License
/* Copyright 2016-2017 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace HidSharp
{
    public class FilteredDeviceList : DeviceList
    {
        int _dirty;
        List<Func<bool>> _areDriversBeingInstalled;
        Dictionary<Device, int> _refCounts;

        public FilteredDeviceList()
        {
            _areDriversBeingInstalled = new List<Func<bool>>();
            _refCounts = new Dictionary<Device, int>();
        }

        public void Add(Device device)
        {
            Throw.If.Null(device, "device");

            lock (_refCounts)
            {
                IncrementRefCount(device);
            }

            RaiseChangedIfDirty();
        }

        public void Add(DeviceList deviceList)
        {
            Add(deviceList, device => true);
        }

        public void Add(DeviceList deviceList, DeviceFilter filter)
        {
            Throw.If.Null(deviceList, "deviceList").Null(filter, "filter");

            var oldDevices = new Device[0];
            Action updateDeviceList = () =>
            {
                var newDevices = deviceList.GetAllDevices(filter).ToArray();

                lock (_refCounts)
                {
                    foreach (var newDevice in newDevices)
                    {
                        IncrementRefCount(newDevice);
                    }

                    foreach (var oldDevice in oldDevices)
                    {
                        DecrementRefCount(oldDevice);
                    }
                }

                oldDevices = newDevices;
                RaiseChangedIfDirty();
            };

            _areDriversBeingInstalled.Add(() => deviceList.AreDriversBeingInstalled);
            deviceList.Changed += (sender, e) => updateDeviceList();
            updateDeviceList();
        }

        public override IEnumerable<Device> GetAllDevices()
        {
            lock (_refCounts)
            {
                return _refCounts.Keys.ToList();
            }
        }

        void IncrementRefCount(Device device)
        {
            if (_refCounts.ContainsKey(device))
            {
                _refCounts[device]++;
            }
            else
            {
                _refCounts[device] = 1; _dirty = 1;
            }
        }

        void DecrementRefCount(Device device)
        {
            if (--_refCounts[device] == 0)
            {
                _refCounts.Remove(device); _dirty = 1;
            }
        }

        void RaiseChangedIfDirty()
        {
            if (1 == Interlocked.CompareExchange(ref _dirty, 0, 1))
            {
                RaiseChanged();
            }
        }

        public override bool AreDriversBeingInstalled
        {
            get { return _areDriversBeingInstalled.Any(callback => callback()); }
        }
    }
}
