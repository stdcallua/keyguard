﻿#region License
/* Copyright 2010-2013 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;

namespace HidSharp
{
    /// <summary>
    /// Represents a USB HID class device.
    /// </summary>
    [ComVisible(true), Guid("4D8A9A1A-D5CC-414e-8356-5A025EDA098D")]
    public abstract class HidDevice : Device
    {
        /// <inheritdoc/>
        public new HidStream Open()
        {
            return (HidStream)base.Open(null);
        }

        /// <inheritdoc/>
        public new HidStream Open(OpenConfiguration openConfig)
        {
            return (HidStream)base.Open(openConfig);
        }

        /// <inheritdoc/>
        public override string GetFriendlyName()
        {
            return GetProductName();
        }

        /// <summary>
        /// Returns the manufacturer name.
        /// </summary>
        public abstract string GetManufacturer();

        /// <summary>
        /// Returns the product name.
        /// </summary>
        public abstract string GetProductName();

        /// <summary>
        /// Returns the device serial number.
        /// </summary>
        public abstract string GetSerialNumber();

        /// <summary>
        /// Returns the maximum input report length, including the Report ID byte.
        /// If the device does not use Report IDs, the first byte will always be 0.
        /// </summary>
        public abstract int GetMaxInputReportLength();

        /// <summary>
        /// Returns the maximum output report length, including the Report ID byte.
        /// If the device does not use Report IDs, use 0 for the first byte.
        /// </summary>
        public abstract int GetMaxOutputReportLength();

        /// <summary>
        /// Returns the maximum feature report length, including the Report ID byte.
        /// If the device does not use Report IDs, use 0 for the first byte.
        /// </summary>
        public abstract int GetMaxFeatureReportLength();

        /// <summary>
        /// Returns the raw report descriptor of the USB device.
        /// Currently this is only supported on Linux.
        /// </summary>
        /// <returns>The report descriptor.</returns>
        public virtual byte[] GetReportDescriptor()
        {
            throw new NotSupportedException(); // Windows without libusb can't... Linux can.
        }

        /// <summary>
        /// Returns the serial ports of the composite USB device.
        /// Currently this is only supported on Windows.
        /// </summary>
        /// <returns>Serial ports of the USB device.</returns>
        public virtual string[] GetSerialPorts()
        {
            throw new NotSupportedException();
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            string manufacturer = "(unnamed manufacturer)";
            try { manufacturer = GetManufacturer(); } catch { }

            string productName = "(unnamed product)";
            try { productName = GetProductName(); } catch { }

            string serialNumber = "(no serial number)";
            try { serialNumber = GetSerialNumber(); } catch { }

            return string.Format(CultureInfo.InvariantCulture, "{0} {1} {2} (VID {3}, PID {4}, version {5})",
                manufacturer, productName, serialNumber, VendorID, ProductID, ReleaseNumber);
        }

        /// <inheritdoc/>
        public bool TryOpen(out HidStream stream)
        {
            return TryOpen(null, out stream);
        }

        /// <inheritdoc/>
        public bool TryOpen(OpenConfiguration openConfig, out HidStream stream)
        {
            DeviceStream baseStream;
            bool result = base.TryOpen(openConfig, out baseStream);
            stream = (HidStream)baseStream; return result;
		}

        /// <summary>
        /// The USB product ID. These are listed at: http://usb-ids.gowdy.us
        /// </summary>
        public abstract int ProductID
        {
            get;
        }

        /// <summary>
        /// The device release number.
        /// </summary>
        public Version ReleaseNumber
        {
            get { return Utility.BcdHelper.ToVersion(ReleaseNumberBcd); }
        }

        /// <summary>
        /// The device release number, in binary-coded decimal.
        /// </summary>
        public abstract int ReleaseNumberBcd
        {
            get;
        }

        /// <exclude />
        [Obsolete("Use ReleaseNumberBcd instead."), EditorBrowsable(EditorBrowsableState.Never)]
        public virtual int ProductVersion
        {
            get { return ReleaseNumberBcd; }
        }

        /// <summary>
        /// The USB vendor ID. These are listed at: http://usb-ids.gowdy.us
        /// </summary>
        public abstract int VendorID
        {
            get;
        }

        /// <exclude />
        [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
        public virtual string Manufacturer
        {
            get
            {
                try
                {
                    return GetManufacturer() ?? "";
                }
                catch (IOException)
                {
                    return "";
                }
                catch (UnauthorizedAccessException)
                {
                    return "";
                }
            }
        }

        /// <exclude />
        [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
        public virtual string ProductName
        {
            get
            {
                try
                {
                    return GetProductName() ?? "";
                }
                catch (IOException)
                {
                    return "";
                }
                catch (UnauthorizedAccessException)
                {
                    return "";
                }
            }
        }

        /// <exclude />
        [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
        public virtual string SerialNumber
        {
            get
            {
                try
                {
                    return GetSerialNumber() ?? "";
                }
                catch (IOException)
                {
                    return "";
                }
                catch (UnauthorizedAccessException)
                {
                    return "";
                }
            }
        }

        /// <exclude />
        [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
        public virtual int MaxInputReportLength
        {
            get
            {
                try
                {
                    return GetMaxInputReportLength();
                }
                catch (IOException)
                {
                    return 0;
                }
                catch (UnauthorizedAccessException)
                {
                    return 0;
                }
            }
        }

        /// <exclude />
        [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
        public virtual int MaxOutputReportLength
        {
            get
            {
                try
                {
                    return GetMaxOutputReportLength();
                }
                catch (IOException)
                {
                    return 0;
                }
                catch (UnauthorizedAccessException)
                {
                    return 0;
                }
            }
        }

        /// <exclude />
        [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
        public virtual int MaxFeatureReportLength
        {
            get
            {
                try
                {
                    return GetMaxFeatureReportLength();
                }
                catch (IOException)
                {
                    return 0;
                }
                catch (UnauthorizedAccessException)
                {
                    return 0;
                }
            }
        }
    }
}
