﻿#region License
/* Copyright 2010, 2013 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace HidSharp
{
    /// <exclude />
    [ComVisible(true), Guid("CD7CBD7D-7204-473c-AA2A-2B9622CFC6CC")]
    [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
    public class HidDeviceLoader : DeviceList
    {
        /// <exclude />
        [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
        public IEnumerable GetDevicesVB()
        {
            return GetHidDevices();
        }

        /// <exclude />
        [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
        public IEnumerable<HidDevice> GetDevices()
        {
            return GetHidDevices();
        }

        /// <exclude />
        [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
        public IEnumerable<HidDevice> GetDevices(int? vendorID = null, int? productID = null, int? productVersion = null, string serialNumber = null)
        {
            return GetHidDevices(vendorID, productID, productVersion, serialNumber);
        }

        [Obsolete, EditorBrowsable(EditorBrowsableState.Never)]
        public HidDevice GetDeviceOrDefault(int? vendorID = null, int? productID = null, int? productVersion = null, string serialNumber = null)
        {
            return base.GetHidDeviceOrNull(vendorID, productID, productVersion, serialNumber);
        }
    }
}
