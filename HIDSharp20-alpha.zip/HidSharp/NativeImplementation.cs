﻿#region License
/* Copyright 2017 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System;

namespace HidSharp
{
    /// <summary>
    /// Specifies the <see cref="Device"/>'s low-level implementation.
    /// </summary>
    public static class NativeImplementation
    {
        /// <summary>
        /// The HID device is running on Windows.
        /// </summary>
        public static Guid WindowsHid { get; private set; }

        /// <summary>
        /// The HID device is running on a Mac.
        /// </summary>
        public static Guid MacOSHid { get; private set; }

        /// <summary>
        /// The HID device is running on Linux, using hidraw.
        /// </summary>
        public static Guid LinuxHidraw { get; private set; }

        /// <summary>
        /// The serial device is running on a Mac.
        /// </summary>
        public static Guid MacOSSerial { get; private set; }

        /// <summary>
        /// The serial device is running on Linux.
        /// </summary>
        public static Guid LinuxSerial { get; private set; }

        /// <summary>
        /// The implementation is unknown.
        /// </summary>
        public static Guid Unknown { get; private set; }

        static NativeImplementation()
        {
            WindowsHid = new Guid("{3540D886-E329-419F-8033-1D7355D53A7E}");
            MacOSHid = new Guid("{9FE992E5-F804-41B6-A35F-3B60F7CAC9E2}");
            LinuxHidraw = new Guid("{1199D7C6-F99F-471F-9730-B16BA615938F}");

            MacOSSerial = new Guid("{DFF209D7-131E-4958-8F47-C23DAC7B62DA}");
            LinuxSerial = new Guid("{45A96DA9-AA48-4BF7-978D-A845F185F38C}");

            Unknown = new Guid("{00000000-0000-0000-0000-000000000000}");
        }
    }
}
