﻿#region License
/* Copyright 2016, 2017 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System.Collections.Generic;

namespace HidSharp
{
    /// <summary>
    /// Describes all options for opening a device stream.
    /// </summary>
    public class OpenConfiguration
    {
        Dictionary<OpenOption, object> _options;

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenConfiguration"/> class.
        /// </summary>
        public OpenConfiguration()
        {
            _options = new Dictionary<OpenOption, object>();
        }

        /// <summary>
        /// Gets the current value of an option.
        /// </summary>
        /// <param name="option">The option.</param>
        /// <returns>The option's value.</returns>
        public object GetOption(OpenOption option)
        {
            Throw.If.Null(option, "option");
            
            object value;
            return _options.TryGetValue(option, out value) ? value : option.DefaultValue;
        }

        /// <summary>
        /// Gets a list of all currently set options.
        /// </summary>
        /// <returns>The options list.</returns>
        public IEnumerable<OpenOption> GetOptionsList()
        {
            return _options.Keys;
        }

        /// <summary>
        /// Checks if an option has been set.
        /// </summary>
        /// <param name="option">The option.</param>
        /// <returns><c>true</c> if the option has been set.</returns>
        public bool IsOptionSet(OpenOption option)
        {
            Throw.If.Null(option, "option");

            return _options.ContainsKey(option);
        }

        /// <summary>
        /// Sets the current value of an option.
        /// </summary>
        /// <param name="option">The option.</param>
        /// <param name="value">The value to set it to.</param>
        public void SetOption(OpenOption option, object value)
        {
            Throw.If.Null(option, "option");

            if (value != null)
            {
                _options[option] = value;
            }
            else
            {
                _options.Remove(option);
            }
        }
    }
}
