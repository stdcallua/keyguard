﻿#region License
/* Copyright 2012-2016 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Threading;

namespace HidSharp.Platform
{
    abstract class HidManager
    {
        enum KeyType
        {
            Hid,
            Serial
        }
        struct TypedKey : IEquatable<TypedKey>
        {
            public override bool Equals(object obj)
            {
                return obj is TypedKey && Equals((TypedKey)obj);
            }

            public bool Equals(TypedKey other)
            {
                return Type == other.Type && object.Equals(Key, other.Key);
            }

            public override int GetHashCode()
            {
                return Key.GetHashCode();
            }

            public KeyType Type
            {
                get;
                set;
            }

            public object Key
            {
                get;
                set;
            }
        }
        Dictionary<TypedKey, Device> _deviceList;
        object _getDevicesLock;

        protected HidManager()
        {
            _deviceList = new Dictionary<TypedKey, Device>();
            _getDevicesLock = new object();
        }

        internal void InitializeEventManager()
        {
            EventManager = CreateEventManager();
            EventManager.Start();
        }

        protected virtual SystemEvents.EventManager CreateEventManager()
        {
            return new SystemEvents.DefaultEventManager();
        }

        protected virtual void Run(Action readyCallback)
        {
            readyCallback();
        }

        internal void RunImpl(object readyEvent)
        {
            Run(() => ((ManualResetEvent)readyEvent).Set());
        }

        protected static void RunAssert(bool condition, string error)
        {
            if (!condition) { throw new InvalidOperationException(error); }
        }

        public IEnumerable<Device> GetDevices()
        {
            Device[] deviceList;
            
            lock (_getDevicesLock)
            {
                TypedKey[] devices = GetAllDeviceKeys();
                TypedKey[] additions = devices.Except(_deviceList.Keys).ToArray();
                TypedKey[] removals = _deviceList.Keys.Except(devices).ToArray();

                if (additions.Length > 0)
                {
                    int completedAdditions = 0;

                    foreach (TypedKey addition in additions)
                    {
                        ThreadPool.QueueUserWorkItem(new WaitCallback(addition_ =>
                            {
                                var typedKey = (TypedKey)addition_;

                                Device device = null; bool created;

                                switch (typedKey.Type)
                                {
                                    case KeyType.Hid:
                                        created = TryCreateHidDevice(typedKey.Key, out device);
                                        break;

                                    case KeyType.Serial:
                                        created = TryCreateSerialDevice(typedKey.Key, out device);
                                        break;

                                    default:
                                        created = false; Debug.Assert(false);
                                        break;
                                }

                                if (created)
                                {
                                    // By not adding on failure, we'll end up retrying every time.
                                    lock (_deviceList)
                                    {
                                        _deviceList.Add(typedKey, device);
                                        Debug.Print("** HIDSharp detected a new device: {0}", typedKey.Key);
                                    }
                                }

                                lock (_deviceList)
                                {
                                    completedAdditions++; Monitor.Pulse(_deviceList);
                                }
                            }), addition);
                    }

                    lock (_deviceList)
                    {
                        while (completedAdditions != additions.Length) { Monitor.Wait(_deviceList); }
                    }
                }

                foreach (TypedKey removal in removals)
                {
                    _deviceList.Remove(removal);
                    Debug.Print("** HIDSharp detected a device removal: {0}", removal.Key);
                }
                deviceList = _deviceList.Values.ToArray();
            }

            return deviceList;
        }

        TypedKey[] GetAllDeviceKeys()
        {
            return GetHidDeviceKeys().Select(key => new TypedKey() { Key = key, Type = KeyType.Hid })
                .Concat(GetSerialDeviceKeys().Select(key => new TypedKey() { Key = key, Type = KeyType.Serial }))
                .ToArray();
        }

        protected abstract object[] GetHidDeviceKeys();

        protected virtual object[] GetSerialDeviceKeys()
        {
            try
            {
                return SerialPort.GetPortNames();
            }
            catch
            {
                return new string[0];
            }
        }

        protected abstract bool TryCreateHidDevice(object key, out Device device);

        protected virtual bool TryCreateSerialDevice(object key, out Device device)
        {
            device = SysSerialDevice.TryCreate((string)key); return true;
        }

        public virtual bool AreDriversBeingInstalled
        {
            get { return false; }
        }

        public SystemEvents.EventManager EventManager
        {
            get;
            private set;
        }

        public abstract string FriendlyName
        {
            get;
        }

        public abstract bool IsSupported
        {
            get;
        }
    }
}
