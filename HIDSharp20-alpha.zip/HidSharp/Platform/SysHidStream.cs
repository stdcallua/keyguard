﻿#region License
/* Copyright 2012-2013, 2016 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace HidSharp.Platform
{
    abstract class SysHidStream : HidStream
    {
        int _opened, _closed;
        int _refCount;

        protected SysHidStream(HidDevice device)
            : base(device)
        {

        }

        internal class CommonOutputReport
        {
            public byte[] Bytes;
            public bool DoneOK, Feature;
            public volatile bool Done;
        }

        internal static int GetTimeout(int startTime, int timeout)
        {
            return Math.Min(timeout, Math.Max(0, startTime + timeout - Environment.TickCount));
        }

        internal int CommonRead(byte[] buffer, int offset, int count, Queue<byte[]> queue)
        {
            Throw.If.OutOfRange(buffer, offset, count);
            if (count == 0) { return 0; }

            int readTimeout = ReadTimeout;
            int startTime = Environment.TickCount;
            int timeout;

            HandleAcquireIfOpenOrFail();
            try
            {
                lock (queue)
                {
                    while (true)
                    {
                        if (queue.Count > 0)
                        {
                            byte[] packet = queue.Dequeue();
                            count = Math.Min(count, packet.Length);
                            Array.Copy(packet, 0, buffer, offset, count);
                            return count;
                        }

                        timeout = GetTimeout(startTime, readTimeout);
                        if (_closed != 0) { throw new IOException("Closed."); }
                        if (!Monitor.Wait(queue, timeout)) { throw new TimeoutException(); }
                    }
                }
            }
            finally
            {
                HandleRelease();
            }
        }

        internal void CommonWrite(byte[] buffer, int offset, int count,
                                  Queue<CommonOutputReport> queue,
                                  bool feature, int maxOutputReportLength)
        {
            Throw.If.OutOfRange(buffer, offset, count);
            count = Math.Min(count, maxOutputReportLength);
            if (count == 0) { return; }

            int writeTimeout = WriteTimeout;
            int startTime = Environment.TickCount;
            int timeout;

            HandleAcquireIfOpenOrFail();
            try
            {
                lock (queue)
                {
                    while (true)
                    {
                        if (queue.Count == 0)
                        {
                            byte[] packet = new byte[count];
                            Array.Copy(buffer, offset, packet, 0, count);
                            var outputReport = new CommonOutputReport() { Bytes = packet, Feature = feature };
                            queue.Enqueue(outputReport);
                            Monitor.PulseAll(queue);

                            while (true)
                            {
                                if (outputReport.Done)
                                {
                                    if (!outputReport.DoneOK) { throw new IOException(); }
                                    return;
                                }

                                timeout = GetTimeout(startTime, writeTimeout);
                                if (_closed != 0) { throw new IOException("The stream is closed."); }
                                if (!Monitor.Wait(queue, timeout)) { throw new TimeoutException(); }
                            }
                        }
                        else
                        {
                            timeout = GetTimeout(startTime, writeTimeout);
                            if (_closed != 0) { throw new IOException("The stream is closed."); }
                            if (!Monitor.Wait(queue, timeout)) { throw new TimeoutException(); }
                        }
                    }
                }
            }
            finally
            {
                HandleRelease();
            }
        }

        internal void HandleInitAndOpen()
        {
            _opened = 1; _refCount = 1;
        }

        internal bool HandleClose()
        {
            return 0 == Interlocked.CompareExchange(ref _closed, 1, 0) && _opened != 0;
        }

        internal bool HandleAcquire()
        {
            while (true)
            {
                int refCount = _refCount;
                if (refCount == 0) { return false; }

                if (refCount == Interlocked.CompareExchange
                    (ref _refCount, refCount + 1, refCount))
                {
                    return true;
                }
            }
        }

        internal void HandleAcquireIfOpenOrFail()
        {
            if (_closed != 0 || !HandleAcquire()) { throw new IOException("Closed."); }
        }

        internal void HandleRelease()
        {
            if (0 == Interlocked.Decrement(ref _refCount))
            {
                if (_opened != 0) { HandleFree(); }
            }
        }

        internal abstract void HandleFree();

        public sealed override int ReadTimeout
        {
            get;
            set;
        }

        public sealed override int WriteTimeout
        {
            get;
            set;
        }
    }
}
