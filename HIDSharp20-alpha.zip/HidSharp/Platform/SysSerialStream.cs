﻿#region License
/* Copyright 2017 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System;
using System.IO;
using System.IO.Ports;
using System.Threading;

namespace HidSharp.Platform
{
    sealed class SysSerialStream : SerialStream
    {
        SerialPort _port;
        int _portOpenTime;
        Stream _stream;

        internal SysSerialStream(SysSerialDevice device, string devicePath)
            : base(device)
        {
            _portOpenTime = Environment.TickCount;
            _port = new SerialPort();
            _port.DataBits = 8;
            _port.Parity = Parity.None;
            _port.StopBits = StopBits.One;
            _port.BaudRate = 9600;
            try
            {
                _port.PortName = devicePath;
                _port.Open();
            }
            catch (IOException e)
            {
                try
                {
                    _port.PortName = @"\\.\" + devicePath; // Support COM10+ on Mono.
                }
                catch (ArgumentException)
                {
                    throw e; // If we aren't on Mono, throw the original exception.
                }

                _port.Open();
            }
            _port.DiscardInBuffer();
            _stream = _port.BaseStream;
        }

        protected override void Dispose(bool disposing)
        {
            try
            {
                var stream = _stream;
                if (stream != null)
                {
                    // .NET SerialPort is completely terrible. If you close immediately after opening, it *will* lock.
                    // Also, it will return from Close() before it has actually closed. To make things better, as far as I can tell,
                    // there is no property one can query to find out when it's been enough time.
                    // Sleeping is a hack. If you have a better way, let me know.
                    Thread.Sleep((int)Math.Min(100, (uint)(Environment.TickCount - _portOpenTime)));
                    stream.Close();
                    Thread.Sleep(100);

                }
            }
            catch
            {

            }
            finally
            {
                _stream = null;
            }

            base.Dispose(disposing);
        }

        public override void Flush()
        {
            var stream = _stream;
            if (stream != null) { stream.Flush(); }
        }

        public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
        {
            UpdateSettings();
            return _stream.BeginRead(buffer, offset, count, callback, state);
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            UpdateSettings();
            return _stream.Read(buffer, offset, count);
        }

        public override int EndRead(IAsyncResult asyncResult)
        {
            return _stream.EndRead(asyncResult);
        }

        public override IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
        {
            UpdateSettings();
            return _stream.BeginWrite(buffer, offset, count, callback, state);
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            UpdateSettings();
            _stream.Write(buffer, offset, count);
        }

        public override void EndWrite(IAsyncResult asyncResult)
        {
            _stream.EndWrite(asyncResult);
        }

        void UpdateSettings()
        {
            if (_port.BaudRate != BaudRate)
            {
                _port.BaudRate = BaudRate;
                _port.DiscardInBuffer();
            }

            if (_port.ReadTimeout != ReadTimeout)
            {
                _port.ReadTimeout = ReadTimeout;
            }

            if (_port.WriteTimeout != WriteTimeout)
            {
                _port.WriteTimeout = WriteTimeout;
            }
        }

        public sealed override int BaudRate
        {
            get;
            set;
        }

        public sealed override int ReadTimeout
        {
            get;
            set;
        }

        public sealed override int WriteTimeout
        {
            get;
            set;
        }
    }
}
