﻿#region License
/* Copyright 2010-2015 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

#pragma warning disable 618

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace HidSharp.Platform.Windows
{
    sealed class WinHidDevice : HidDevice
    {
        [Flags]
        enum GetInfoFlags
        {
            Manufacturer = 1,
            ProductName = 2,
            SerialNumber = 4,
            ReportLengths = 8
        }
        GetInfoFlags _getInfoFlags;
        object _getInfoLock = new object();
        string _path, _id;
        string _manufacturer;
        string _productName;
        string _serialNumber;
        int _vid, _pid, _version;
        int _maxInput, _maxOutput, _maxFeature;

        WinHidDevice()
        {

        }

        internal static WinHidDevice TryCreate(string path, string id)
        {
            var d = new WinHidDevice() { _path = path, _id = id };

            return d.TryOpenToGetInfo(handle =>
                {
                    NativeMethods.HIDD_ATTRIBUTES attributes = new NativeMethods.HIDD_ATTRIBUTES();
                    attributes.Size = Marshal.SizeOf(attributes);
                    if (!NativeMethods.HidD_GetAttributes(handle, ref attributes)) { return false; }

                    // Get VID, PID, version.
                    d._pid = attributes.ProductID;
                    d._vid = attributes.VendorID;
                    d._version = attributes.VersionNumber;
                    return true;
                }) ? d : null;
        }

        bool TryOpenToGetInfo(Func<IntPtr, bool> action)
        {
            var handle = NativeMethods.CreateFileFromDevice(_path, NativeMethods.EFileAccess.None, NativeMethods.EFileShare.Read | NativeMethods.EFileShare.Write);
            if (handle == (IntPtr)(-1)) { return false; }

            try
            {
                return action(handle);
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
            }
            finally
            {
                NativeMethods.CloseHandle(handle);
            }

            return false;
        }

        protected override DeviceStream OpenDeviceDirectly(OpenConfiguration openConfig)
        {
            RequiresGetInfo(GetInfoFlags.ReportLengths);

            var stream = new WinHidStream(this);
            try { stream.Init(_path); return stream; }
            catch { stream.Close(); throw; }
        }

        void RequiresGetInfo(GetInfoFlags flags)
        {
            lock (_getInfoLock)
            {
                flags &= ~_getInfoFlags; // Remove flags we already have.
                if (flags == 0) { return; }

                if (!TryOpenToGetInfo(handle =>
                    {
                        if ((flags & GetInfoFlags.Manufacturer) != 0)
                        {
                            if (!TryGetDeviceString(handle, NativeMethods.HidD_GetManufacturerString, out _manufacturer)) { return false; }
                        }

                        if ((flags & GetInfoFlags.ProductName) != 0)
                        {
                            if (!TryGetDeviceString(handle, NativeMethods.HidD_GetProductString, out _productName)) { return false; }
                        }

                        if ((flags & GetInfoFlags.SerialNumber) != 0)
                        {
                            if (!TryGetDeviceString(handle, NativeMethods.HidD_GetSerialNumberString, out _serialNumber)) { return false; }
                        }

                        if ((flags & GetInfoFlags.ReportLengths) != 0)
                        {
                            IntPtr preparsed;
                            if (!NativeMethods.HidD_GetPreparsedData(handle, out preparsed)) { return false; }

                            try
                            {
                                NativeMethods.HIDP_CAPS caps;
                                int statusCaps = NativeMethods.HidP_GetCaps(preparsed, out caps);
                                if (statusCaps != NativeMethods.HIDP_STATUS_SUCCESS) { return false; }

                                _maxInput = caps.InputReportByteLength;
                                _maxOutput = caps.OutputReportByteLength;
                                _maxFeature = caps.FeatureReportByteLength;
                            }
                            finally
                            {
                                NativeMethods.HidD_FreePreparsedData(preparsed);
                            }
                        }

                        return true;
                    }))
                {
                    throw DeviceException.CreateIOException(this, "Failed to get info.");
                }

                _getInfoFlags |= flags;
            }
        }

        bool TryGetDeviceString(IntPtr handle, Func<IntPtr, char[], int, bool> callback, out string s)
        {
            char[] buffer = new char[128];
            if (!callback(handle, buffer, Marshal.SystemDefaultCharSize * buffer.Length))
            {
                s = null;
                return Marshal.GetLastWin32Error() == NativeMethods.ERROR_GEN_FAILURE;
            }
            s = NativeMethods.NTString(buffer); return true;
        }

        public override string GetManufacturer()
        {
            RequiresGetInfo(GetInfoFlags.Manufacturer);
            return _manufacturer;
        }

        public override string GetProductName()
        {
            RequiresGetInfo(GetInfoFlags.ProductName);
            return _productName;
        }

        public override string GetSerialNumber()
        {
            RequiresGetInfo(GetInfoFlags.SerialNumber);
            return _serialNumber;
        }

        public override int GetMaxInputReportLength()
        {
            RequiresGetInfo(GetInfoFlags.ReportLengths);
            return _maxInput;
        }

        public override int GetMaxOutputReportLength()
        {
            RequiresGetInfo(GetInfoFlags.ReportLengths);
            return _maxOutput;
        }

        public override int GetMaxFeatureReportLength()
        {
            RequiresGetInfo(GetInfoFlags.ReportLengths);
            return _maxFeature;
        }

        /*
        public override byte[] GetReportDescriptor()
        {
            Guid hubGuid = new Guid("{3ABF6F2D-71C4-462a-8A92-1E6861E6AF27}");

            uint devInst;
            if (0 == NativeMethods.CM_Locate_DevNode(out devInst, _id))
            {
                while (true)
                {
                    string deviceID;
                    if (0 != NativeMethods.CM_Get_Device_ID(devInst, out deviceID)) { break; }

                    NativeMethods.HDEVINFO hubDevInfo = NativeMethods.SetupDiGetClassDevs(hubGuid, deviceID, IntPtr.Zero,
                        NativeMethods.DIGCF.DeviceInterface | NativeMethods.DIGCF.Present);

                    if (hubDevInfo.IsValid)
                    {
                        try
                        {
                            NativeMethods.SP_DEVINFO_DATA dvi = new NativeMethods.SP_DEVINFO_DATA();
                            dvi.Size = Marshal.SizeOf(dvi);

                            for (int i = 0; NativeMethods.SetupDiEnumDeviceInfo(hubDevInfo, i, ref dvi); i++)
                            {
                                while (true) ;
                            }
                        }
                        finally
                        {
                            NativeMethods.SetupDiDestroyDeviceInfoList(hubDevInfo);
                        }
                    }

                    if (0 != NativeMethods.CM_Get_Parent(out devInst, devInst)) { break; }
                }
            }

            return base.GetReportDescriptor();
        }
         * */

        public override string[] GetSerialPorts()
        {
            uint devInst;
            bool found = false;
            List<string> ports = new List<string>();

            if (0 == NativeMethods.CM_Locate_DevNode(out devInst, _id))
            {
                // Get the USB root of the device.
                while (true)
                {
                    uint parentDevInst;
                    if (0 != NativeMethods.CM_Get_Parent(out parentDevInst, devInst)) { break; }

                    string parentDeviceID;
                    if (0 != NativeMethods.CM_Get_Device_ID(parentDevInst, out parentDeviceID)) { break; }
                    if (!parentDeviceID.StartsWith(@"USB\") && !parentDeviceID.StartsWith(@"HID\")) { break; }

                    devInst = parentDevInst;

                    if (Regex.IsMatch(parentDeviceID, @"^USB\\VID_[0-9A-F]{4}&PID_[0-9A-F]{4}\\")) { found = true; break; }
                }

                // Now get its children of the Ports type.
                if (found)
                {
                    if (0 == NativeMethods.CM_Get_Child(out devInst, devInst))
                    {
                        do
                        {
                            string deviceID;
                            if (0 != NativeMethods.CM_Get_Device_ID(devInst, out deviceID)) { break; }

                            Guid comGuid = new Guid("{86E0D1E0-8089-11D0-9CE4-08003E301F73}");
                            NativeMethods.HDEVINFO comDevInfo = NativeMethods.SetupDiGetClassDevs(comGuid, deviceID, IntPtr.Zero,
                                NativeMethods.DIGCF.DeviceInterface | NativeMethods.DIGCF.Present);

                            if (comDevInfo.IsValid)
                            {
                                try
                                {
                                    NativeMethods.SP_DEVINFO_DATA dvi = new NativeMethods.SP_DEVINFO_DATA();
                                    dvi.Size = Marshal.SizeOf(dvi);

                                    for (int j = 0; NativeMethods.SetupDiEnumDeviceInfo(comDevInfo, j, ref dvi); j++)
                                    {
                                        IntPtr hkey = NativeMethods.SetupDiOpenDevRegKey(comDevInfo, ref dvi);
                                        if (hkey == (IntPtr)(-1)) { continue; }

                                        try
                                        {
                                            char[] portName = new char[64]; int portLength = 63;
                                            if (0 == NativeMethods.RegQueryValueEx(hkey, "PortName", 0, IntPtr.Zero, portName, ref portLength))
                                            {
                                                Array.Resize(ref portName, portLength);
                                                ports.Add(NativeMethods.NTString(portName));
                                            }
                                        }
                                        finally
                                        {
                                            NativeMethods.RegCloseKey(hkey);
                                        }
                                    }
                                }
                                finally
                                {
                                    NativeMethods.SetupDiDestroyDeviceInfoList(comDevInfo);
                                }
                            }
                        }
                        while (0 == NativeMethods.CM_Get_Sibling(out devInst, devInst));
                    }
                }
            }

            return ports.ToArray();
        }

        public override string GetFileSystemName()
        {
            return DevicePath;
        }

        public override string DevicePath
        {
            get { return _path; }
        }

        public override int VendorID
        {
            get { return _vid; }
        }

        public override int ProductID
        {
            get { return _pid; }
        }

        public override int ReleaseNumberBcd
        {
            get { return _version; }
        }

        public override Guid NativeImplementation
        {
            get { return HidSharp.NativeImplementation.WindowsHid; }
        }
    }
}
