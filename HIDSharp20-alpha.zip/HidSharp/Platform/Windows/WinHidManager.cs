﻿#region License
/* Copyright 2012-2013 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace HidSharp.Platform.Windows
{
    sealed class WinHidManager : HidManager
    {
        sealed class HidPath
        {
            public override bool Equals(object obj)
            {
                var path = obj as HidPath;
                return path != null && DevicePath == path.DevicePath && DeviceID == path.DeviceID;
            }

            public override int GetHashCode()
            {
                return DevicePath.GetHashCode();
            }

            public override string ToString()
            {
                return DevicePath;
            }

            public string DevicePath;
            public string DeviceID;
        }

        protected override void Run(Action readyCallback)
        {
            const string className = "HidSharpDeviceMonitor";

            NativeMethods.WindowProc windowProc = DeviceMonitorWindowProc; GC.KeepAlive(windowProc);
            var wc = new NativeMethods.WNDCLASS() { ClassName = className, WindowProc = windowProc };
            RunAssert(0 != NativeMethods.RegisterClass(ref wc), "HidSharp RegisterClass failed.");

            var hwnd = NativeMethods.CreateWindowEx(0, className, className, 0,
                                                    NativeMethods.CW_USEDEFAULT, NativeMethods.CW_USEDEFAULT, NativeMethods.CW_USEDEFAULT, NativeMethods.CW_USEDEFAULT,
                                                    NativeMethods.HWND_MESSAGE,
                                                    IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
            RunAssert(hwnd != IntPtr.Zero, "HidSharp CreateWindow failed.");

            var notifyFilter = new NativeMethods.DEV_BROADCAST_DEVICEINTERFACE()
            {
                Size = Marshal.SizeOf(typeof(NativeMethods.DEV_BROADCAST_DEVICEINTERFACE)),
                ClassGuid = NativeMethods.HidD_GetHidGuid(),
                DeviceType = NativeMethods.DBT_DEVTYP_DEVICEINTERFACE
            };
            var notifyHandle = NativeMethods.RegisterDeviceNotification(hwnd, ref notifyFilter, 0);
            RunAssert(notifyHandle != IntPtr.Zero, "HidSharp RegisterDeviceNotification failed.");

            readyCallback();

            NativeMethods.MSG msg;
            while (true)
            {
                int result = NativeMethods.GetMessage(out msg, hwnd, 0, 0);
                if (result == 0 || result == -1) { break; }

                NativeMethods.TranslateMessage(ref msg);
                NativeMethods.DispatchMessage(ref msg);
            }

            RunAssert(NativeMethods.UnregisterDeviceNotification(notifyHandle), "HidSharp UnregisterDeviceNotification failed.");
            RunAssert(NativeMethods.DestroyWindow(hwnd), "HidSharp DestroyWindow failed.");
            RunAssert(NativeMethods.UnregisterClass(className, IntPtr.Zero), "HidSharp UnregisterClass failed.");
        }

        static IntPtr DeviceMonitorWindowProc(IntPtr window, uint message, IntPtr wParam, IntPtr lParam)
        {
            if (message == NativeMethods.WM_DEVICECHANGE)
            {
                DeviceList.Local.RaiseChanged();
                return (IntPtr)1;
            }

            return NativeMethods.DefWindowProc(window, message, wParam, lParam);
        }

        protected override object[] GetHidDeviceKeys()
        {
            var paths = new List<HidPath>();

            var hidGuid = NativeMethods.HidD_GetHidGuid();
            NativeMethods.HDEVINFO devInfo = NativeMethods.SetupDiGetClassDevs(
                hidGuid, null, IntPtr.Zero, 
                NativeMethods.DIGCF.DeviceInterface | NativeMethods.DIGCF.Present
                );

            if (devInfo.IsValid)
            {
                try
                {
                    NativeMethods.SP_DEVINFO_DATA dvi = new NativeMethods.SP_DEVINFO_DATA();
                    dvi.Size = Marshal.SizeOf(dvi);

                    for (int j = 0; NativeMethods.SetupDiEnumDeviceInfo(devInfo, j, ref dvi); j++)
                    {
                        string deviceID;
                        if (0 != NativeMethods.CM_Get_Device_ID(dvi.DevInst, out deviceID)) { continue; }

                        NativeMethods.SP_DEVICE_INTERFACE_DATA did = new NativeMethods.SP_DEVICE_INTERFACE_DATA(); 
                        did.Size = Marshal.SizeOf(did);

                        for (int i = 0; NativeMethods.SetupDiEnumDeviceInterfaces(devInfo, ref dvi, hidGuid, i, ref did); i++)
                        {
                            NativeMethods.SP_DEVICE_INTERFACE_DETAIL_DATA didetail = new NativeMethods.SP_DEVICE_INTERFACE_DETAIL_DATA();
                            didetail.Size = IntPtr.Size == 8 ? 8 : (4 + Marshal.SystemDefaultCharSize);
                            if (NativeMethods.SetupDiGetDeviceInterfaceDetail(devInfo, ref did, ref didetail,
                                Marshal.SizeOf(didetail) - 4, IntPtr.Zero, IntPtr.Zero))
                            {
                                paths.Add(new HidPath() { DevicePath = didetail.DevicePath, DeviceID = deviceID });
                            }
                        }
                    }
                }
                finally
                {
                    NativeMethods.SetupDiDestroyDeviceInfoList(devInfo);
                }
            }

            return paths.Cast<object>().ToArray();
        }

        protected override bool TryCreateHidDevice(object key, out Device device)
        {
            var path = (HidPath)key;
            device = WinHidDevice.TryCreate(path.DevicePath, path.DeviceID);
            return device != null;
        }

        public override bool AreDriversBeingInstalled
        {
            get
            {
                try
                {
                    return NativeMethods.WAIT_TIMEOUT == NativeMethods.CMP_WaitNoPendingInstallEvents(0);
                }
                catch
                {
                    return false;
                }
            }
        }

        public override string FriendlyName
        {
            get { return "Windows HID"; }
        }

        public override bool IsSupported
        {
            get
            {
                if (Environment.OSVersion.Platform == PlatformID.Win32NT)
                {
                    var version = new NativeMethods.OSVERSIONINFO();
                    version.OSVersionInfoSize = Marshal.SizeOf(typeof(NativeMethods.OSVERSIONINFO));

                    try
                    {
                        if (NativeMethods.GetVersionEx(ref version) && version.PlatformID == 2)
                        {
                            return true;
                        }
                    }
                    catch
                    {
                        // Apparently we have no P/Invoke access.
                    }
                }

                return false;
            }
        }
    }
}
