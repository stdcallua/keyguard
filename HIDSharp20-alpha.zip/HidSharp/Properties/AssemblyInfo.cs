﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Illusory Studios LLC")]
[assembly: AssemblyCopyright("Copyright © 2010-2017 James F. Bellinger <http://www.zer7.com/software/hidsharp>")]
[assembly: AssemblyDescription("C# HID wrappers")]
[assembly: AssemblyProduct("HidSharp")]
[assembly: AssemblyTitle("HidSharp")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
[assembly: AssemblyInformationalVersion("2.0.0-alpha")]

[assembly: ComVisible(false)]
[assembly: Guid("1b874372-4c6c-4acb-9f4a-906f6738cff9")]
