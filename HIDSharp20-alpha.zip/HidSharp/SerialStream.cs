﻿#region License
/* Copyright 2017 James F. Bellinger <http://www.zer7.com/software/hidsharp>

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#endregion

using System.Collections.Generic;
using System.Text;

namespace HidSharp
{
    /// <summary>
    /// Communicates with a serial device.
    /// </summary>
    public abstract class SerialStream : DeviceStream
    {
        string _newLine;

        /// <exclude/>
        protected SerialStream(SerialDevice device)
            : base(device)
        {
            BaudRate = 9600;
            NewLine = "\r\n";
        }

        public string ReadTo(string ending)
        {
            Throw.If.NullOrEmpty(ending, "ending");

            var bytes = new List<byte>();
            var endingBytes = Encoding.GetBytes(ending);
            int matchBytes = 0;

            while (true)
            {
                int @byte = ReadByte();
                if (@byte < 0) { break; }
                bytes.Add((byte)@byte);

                if (@byte == endingBytes[matchBytes])
                {
                    if (++matchBytes == endingBytes.Length)
                    {
                        break;
                    }
                }
                else
                {
                    matchBytes = 0;
                }
            }

            @bytes.RemoveRange(bytes.Count - matchBytes, matchBytes);
            return Encoding.GetString(@bytes.ToArray());
        }

        public string ReadLine()
        {
            return ReadTo(NewLine);
        }

        public void Write(string s)
        {
            Throw.If.Null(s, "s");
            byte[] bytes = Encoding.GetBytes(s);
            Write(bytes, 0, bytes.Length);
        }

        public void WriteLine(string s)
        {
            Throw.If.Null(s, "s");
            Write(s + NewLine);
        }

        public abstract int BaudRate
        {
            get;
            set;
        }

        Encoding Encoding
        {
            get { return Encoding.UTF8; }
        }

        public string NewLine
        {
            get { return _newLine; }
            set
            {
                Throw.If.NullOrEmpty(value, "NewLine");
                _newLine = value;
            }
        }

        /// <summary>
        /// Gets the <see cref="SerialDevice"/> associated with this stream.
        /// </summary>
        public new SerialDevice Device
        {
            get { return (SerialDevice)base.Device; }
        }
    }
}
