﻿using Xunit;
using Should;

namespace HidLibrary.Tests
{
    public class Hid
    {
        [Fact]
        public void Get_Some_Tests_In_Here()
        {
            true.ShouldBeTrue();
        }
    }
}
