/* aes_invsbox.h */
#ifndef AES_INVSBOX_H_
#define AES_INVSBOX_H_

extern const char aes_invsbox[];

#endif
