/* aes_sbox.h */
#ifndef AES_SBOX_H_
#define AES_SBOX_H_

extern const char aes_sbox[];

#endif
