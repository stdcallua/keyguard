// ATDriverioctl.h
//
// Define control codes for ATDriver driver
//

#ifndef __ATDriverioctl__h_
#define __ATDriverioctl__h_

#define ATDRIVER_IOCTL_800 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_ANY_ACCESS)
#endif
