bit        usb_connected;
bit        end_point1_ready;
bit        p_test;
data byte  bmRequestType;
data byte  usb_configuration_nb;
data byte  point1_state;
data byte  endpoint_status[6];
data byte  hid_idle_duration;

extern void usb_init();
extern void usb_enumeration_process();
extern void usb_read_request();
extern void usb_ep_init();
extern void main_task();


extern void usb_get_status_device();
extern void usb_get_status_interface();
extern void usb_get_status_endpoint();

extern void usb_get_descriptor();
extern void usb_get_configuration();
extern void usb_set_address();
extern void usb_set_configuration();
extern void usb_clear_feature();
extern void usb_set_feature();
extern void usb_get_interface();
extern void usb_send_descriptor();
extern void usb_hid_set_report (void);
extern void usb_hid_set_idle (void);
extern void usb_hid_get_idle (void);

extern void hid_get_report();

