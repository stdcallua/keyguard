typedef unsigned char       byte;
typedef unsigned char       uint8;
typedef unsigned int        uint16;
typedef unsigned long int   uint32;
typedef char                int8;
typedef int                 int16;
typedef long int            int32;

#define FALSE   0
#define TRUE    1
