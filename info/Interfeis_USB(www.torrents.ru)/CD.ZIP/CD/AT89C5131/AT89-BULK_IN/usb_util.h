extern byte* usb_send_ep0_packet (byte* tbuf, byte data_length);
extern void STALL();
extern void END_OK();
extern void delay5();
extern void usb_configure_endpoint(byte ep_num, byte ep_type);
extern void usb_reset_endpoint(byte ep_num);

/* =================================================== */
/*   ��।�� ����� �� �㫥��� ����筮� �窥         */
/* =================================================== */
byte * usb_send_ep0_packet(byte* tbuf, byte data_length)
{
  data int  i;
  data byte b;

  Usb_select_ep(0);

  for (i=0; i<data_length; i++){ 
   b = *tbuf;
   Usb_write_byte(b); 
   tbuf++;
  }
  Usb_set_tx_ready();
  return tbuf;
}

/* =================================================== */
/* =================================================== */
void delay5()
{
 data unsigned int i;
 data unsigned int j;
 for (i=0; i<2000; i++) j++;
}

/* =================================================== */
/* =================================================== */
void usb_configure_endpoint(byte ep_num, byte ep_type)
{
  Usb_select_ep(ep_num);
  Usb_configure_ep_type(ep_type); 
}

/* =================================================== */
/* =================================================== */
void usb_reset_endpoint(byte ep_num)
{
  UEPRST = 0x01 << ep_num;
  UEPRST = 0x00;
}

/* =================================================== */
/* =================================================== */
void STALL(){
  Usb_clear_rx_setup();

  Usb_set_stall_request();
  while (!Usb_stall_sent());
  Usb_clear_stall_request();
  Usb_clear_stalled();

  Usb_clear_DIR();
}

/* =================================================== */
/* =================================================== */
void END_OK(){
  Usb_set_tx_ready();
  while ((!(Usb_tx_complete())) || (Usb_setup_received()));
  Usb_clear_tx_complete();
  while ((!(Usb_rx_complete())) || (Usb_setup_received()));
  Usb_clear_rx();
  Usb_clear_DIR();
}

